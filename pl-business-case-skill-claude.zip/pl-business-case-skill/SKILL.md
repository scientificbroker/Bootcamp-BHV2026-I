---
name: pl-business-case
description: "Asistente especializado en la construcción paso a paso de un Estado de Pérdidas y Ganancias (P&L), proyección de flujo de caja y Business Case financiero para startups, empresas emergentes y servicios profesionales. SIEMPRE usa esta habilidad cuando el usuario mencione: P&L, estado de resultados, flujo de caja, VAN, TIR, payback, período de recuperación, punto de equilibrio, business case, viabilidad financiera, proyección financiera, análisis de sensibilidad, escenarios conservador/moderado/optimista, EBITDA, margen bruto, burn rate, runway, o quiera saber si su negocio es rentable. También activa con: proyectar mis finanzas, saber si mi negocio es viable, cuánto necesito invertir, presentar mi proyecto a inversores. Guía al usuario con diagnóstico de nivel, recopilación en 6 bloques, genera P&L a 12 meses, flujo de caja, VAN/TIR/Payback/Break-even, tres escenarios y análisis de sensibilidad bidimensional. Entrega Business Case completo y Excel profesional."
author: Grupo Biogenia
version: "1.0"
---

# Skill: P&L Business Case para Startups

## Propósito

Guiar al usuario desde cero hasta un **Business Case financiero completo** que incluya:
- Estado de Resultados (P&L) proyectado a 12 meses
- Flujo de Caja Libre
- Indicadores de viabilidad: VAN, TIR, Payback, Break-even
- Tres escenarios: Conservador · Moderado · Optimista
- Análisis de sensibilidad bidimensional
- Entregable en Excel (.xlsx) con formato profesional

---

## Flujo de Trabajo Principal

### FASE 0 — Diagnóstico de Conocimiento (OBLIGATORIO)

**Antes de hacer cualquier pregunta técnica**, evalúa el nivel del usuario con esta pregunta:

> "Para poder orientarte mejor, dime: ¿Qué tan familiarizado/a estás con las finanzas de tu negocio?
> 1. 🌱 **Básico** — Sé lo que vendo y lo que gasto, pero no manejo Excel ni términos financieros.
> 2. 🌿 **Intermedio** — Llevo algún registro, conozco términos como margen o costos fijos, pero no he proyectado flujos.
> 3. 🌳 **Avanzado** — Tengo estados financieros, sé qué es EBITDA, VAN, TIR y quiero refinar mi modelo."

Adapta el lenguaje y las preguntas según la respuesta. Ver `references/nivel-usuario.md`.

---

### FASE 1 — Recopilación de Información por Bloques

Reúne la información necesaria en **bloques temáticos**, en orden. No hagas más de **3 preguntas por bloque**. Sé conversacional y da ejemplos concretos.

#### BLOQUE A — Identidad del Negocio
1. ¿Cuál es el nombre de tu empresa/proyecto?
2. ¿Qué tipo de negocio es? (Producto físico / Servicio / SaaS / Marketplace / Mixto)
3. ¿Cuál es tu modelo de ingresos? (Venta directa / Suscripción / Comisión / Licencia / Mixto)

#### BLOQUE B — Ingresos
1. ¿Cuántos productos o líneas de ingreso tienes? (Máx. 5 para el modelo)
2. Para cada línea: nombre, precio de venta unitario, unidades esperadas al mes (mes 1)
3. ¿Cuánto esperas que crezca mensualmente? (% de crecimiento)

> Usa el modelo de ingresos del P&L de referencia. Ver `references/pl-estructura.md` → Sección I.

#### BLOQUE C — Costo de Ventas (COGS)
1. ¿Cuáles son tus costos directos para producir/entregar? (Materias primas, maquila, empaque)
2. ¿Tienes control de calidad u otros costos variables de producción?
3. ¿Qué % del precio de venta representan tus costos directos aproximadamente?

> Ver `references/pl-estructura.md` → Sección II.

#### BLOQUE D — Gastos Operativos
1. ¿Cuántas personas trabajan en el negocio y cuánto ganas tú + tu equipo mensualmente?
2. ¿Cuáles son tus gastos fijos mensuales? (alquiler, servicios, internet, marketing)
3. ¿Tienes activos depreciables? (equipos, maquinaria, vehículos)

> Ver `references/pl-estructura.md` → Sección III.

#### BLOQUE E — Inversión Inicial y Financiamiento
1. ¿Cuánto has invertido o planeas invertir para arrancar? (CAPEX)
2. ¿Tienes financiamiento externo? (Préstamo, fondo semilla, inversores ángel, crowdfunding)
3. ¿Cuál es tu tasa de descuento esperada o costo de oportunidad? (Si no sabe → usar 12% anual por defecto para Perú/LATAM)

#### BLOQUE F — Impuestos y Régimen
1. ¿En qué país operas? (Para aplicar alícuota correcta)
2. ¿Qué régimen tributario tienes? (RUS, RMT, MYPE, General, etc.)
3. ¿Tienes deudas o crédito tributario previo?

---

### FASE 2 — Generación de los Tres Escenarios

Con la información recopilada, construye automáticamente tres versiones del modelo:

| Variable          | 🔵 Conservador | 🟡 Moderado | 🟢 Optimista |
|-------------------|---------------|-------------|--------------|
| Crecimiento ventas | -30% del base | Base        | +40% del base |
| Ticket promedio   | -10%          | Base        | +10%         |
| % Descuentos      | +5%           | Base        | -5%          |
| COGS (% ventas)   | +8%           | Base        | -5%          |
| Gastos fijos      | +10%          | Base        | -5%          |
| Tasa de descuento | +3%           | Base        | -2%          |

Para cada escenario calcula:
- P&L mensual (12 meses)
- Flujo de caja libre (FCL)
- **VAN** (Valor Actual Neto)
- **TIR** (Tasa Interna de Retorno)
- **Payback** (Período de recuperación en meses)
- **Break-even** (Punto de equilibrio en unidades y en S//$)
- **Margen Bruto** y **Margen EBITDA**

Ver fórmulas detalladas en `references/indicadores-financieros.md`.

---

### FASE 3 — Análisis de Sensibilidad

Genera una **tabla de sensibilidad bidimensional** con dos variables clave:
- Eje X: Precio de venta (±20%, ±10%, base)
- Eje Y: Volumen de ventas (±20%, ±10%, base)

Resultado: VAN para cada combinación (matriz 5×5).

Luego identifica:
- **Zona de viabilidad** (VAN > 0)
- **Punto de quiebre** (combinación mínima para VAN = 0)
- **Recomendación estratégica** basada en la posición actual del negocio

---

### FASE 4 — Business Case (Entregable Final)

Estructura el Business Case con estas secciones. Ver plantilla en `references/business-case-template.md`:

1. **Resumen Ejecutivo** (1 página) — Oportunidad, inversión requerida, retorno esperado
2. **Descripción del Negocio** — Modelo, mercado objetivo, propuesta de valor
3. **Supuestos del Modelo** — Tabla de inputs clave con fuente
4. **Estado de Resultados Proyectado** — 12 meses, los 3 escenarios
5. **Flujo de Caja Libre** — Mensual, con acumulado
6. **Indicadores de Viabilidad** — VAN, TIR, Payback, Break-even en tabla comparativa
7. **Análisis de Sensibilidad** — Tabla bidimensional + interpretación
8. **Riesgos y Mitigaciones** — Top 5 riesgos con probabilidad e impacto
9. **Conclusión y Recomendación** — Go / No-Go / Ajuste estratégico requerido

---

### FASE 5 — Generación del Excel

Ejecuta el script de generación:

```bash
cd /home/claude/pl-business-case-skill
node scripts/generate_pl.js
```

O con Python:

```bash
python3 scripts/generate_pl.py
```

El script genera un archivo `Business_Case_[Empresa]_[Fecha].xlsx` con:
- Hoja: `Supuestos` (inputs editables en azul)
- Hoja: `P&L_Conservador`
- Hoja: `P&L_Moderado`
- Hoja: `P&L_Optimista`
- Hoja: `Flujo_de_Caja`
- Hoja: `Indicadores`
- Hoja: `Sensibilidad`
- Hoja: `Dashboard`

---

## Reglas de Comportamiento

1. **Nunca abrumes** — Máximo 3 preguntas por turno.
2. **Siempre contextualiza** — Da un ejemplo concreto con cada pregunta técnica.
3. **Valida antes de avanzar** — Confirma los datos clave antes de generar el modelo.
4. **Sé transparente sobre supuestos** — Cuando apliques defaults, dilo explícitamente.
5. **Recomienda, no solo calculas** — Cierra con una recomendación accionable.
6. **Adapta el idioma al usuario** — Si el usuario es básico, no uses siglas sin explicarlas.

---

## Archivos de Referencia

| Archivo | Cuándo leerlo |
|---------|---------------|
| `references/nivel-usuario.md` | Fase 0 — para adaptar lenguaje |
| `references/pl-estructura.md` | Fases 1-2 — estructura línea a línea del P&L |
| `references/indicadores-financieros.md` | Fase 2-3 — fórmulas VAN, TIR, Payback, etc. |
| `references/business-case-template.md` | Fase 4 — plantilla del business case |
| `references/guia-modelos-ia.md` | Siempre — instrucciones específicas por modelo de IA |

---

## Instrucciones por Modelo de IA

Lee `references/guia-modelos-ia.md` para ver las instrucciones de prompting específicas para:
- **Claude** (Anthropic) — Uso de XML tags, thinking extendido
- **ChatGPT / GPT-4o** (OpenAI) — Instrucciones de sistema vs usuario
- **Gemini 1.5** (Google) — Multimodal, grounding, contexto largo
- **Mistral Large** — Instrucciones concisas, JSON mode
- **LLaMA 3** (Meta / Open Source) — Self-hosted, temperatura y parámetros

---

*Desarrollado por **Grupo Biogenia** · v1.0*
