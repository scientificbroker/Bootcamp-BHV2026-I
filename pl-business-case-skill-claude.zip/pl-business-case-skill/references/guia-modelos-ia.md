# Guía de Uso por Modelo de IA — P&L Business Case Skill

Esta guía explica cómo usar el skill de Business Case P&L en diferentes modelos de lenguaje.
Cada modelo tiene fortalezas distintas y requiere estrategias de prompting específicas.

---

## 🟣 CLAUDE (Anthropic) — claude-opus-4 / claude-sonnet-4

### Fortalezas para este skill
- Razonamiento matemático extendido y verificable
- Excelente manejo de tablas estructuradas en Markdown
- Puede generar y ejecutar código Python para los cálculos
- Thinking mode para revisión paso a paso de supuestos

### Prompts de sistema recomendados

#### Prompt de inicio (pegar en la primera instrucción)
```xml
<role>
Eres un asesor financiero especializado en startups y empresas emergentes de LATAM.
Tu misión es guiar al usuario en la construcción de su Business Case financiero completo,
incluyendo P&L proyectado, flujo de caja, indicadores de viabilidad (VAN, TIR, Payback),
análisis de sensibilidad y tres escenarios (Conservador, Moderador, Optimista).
</role>

<style>
- Adapta tu lenguaje al nivel del usuario (Básico / Intermedio / Avanzado).
- Nunca hagas más de 3 preguntas por turno.
- Siempre confirma los datos antes de calcular.
- Presenta los números en tablas Markdown limpias.
- Cuando calcules VAN o TIR, muestra la fórmula y los valores paso a paso.
- Usa S/ para soles peruanos, $ para USD. Especifica siempre la moneda.
</style>

<outputs>
Al finalizar, genera:
1. Tabla comparativa de indicadores (3 escenarios)
2. Análisis de sensibilidad 5x5
3. Recomendación Go/No-Go con justificación
4. Script Python/Excel para reproducir el modelo
</outputs>
```

#### Activar razonamiento extendido (Extended Thinking)
```
Por favor, antes de presentar los cálculos, piensa en voz alta sobre:
1. ¿Son coherentes los supuestos entre sí?
2. ¿Hay algún riesgo que el usuario no ha mencionado?
3. ¿Qué supuesto tiene mayor impacto en el VAN?
```

#### Solicitar código ejecutable
```
Genera un script Python que calcule el P&L completo y los indicadores 
con los supuestos que hemos definido. Usa numpy para el cálculo del VAN y TIR.
El script debe poder ejecutarse desde la terminal sin dependencias externas complejas.
```

### Tips específicos para Claude
- Usa XML tags (`<supuestos>`, `<resultados>`, `<recomendacion>`) para estructurar el output
- Claude maneja bien conversaciones largas — puedes pedirle que recuerde los datos del Bloque A mientras pregunta el Bloque D
- Pide que genere el Excel directamente usando `openpyxl` o el script incluido en este skill

---

## 🟢 CHATGPT / GPT-4o (OpenAI)

### Fortalezas para este skill
- Excelente interpretación de archivos Excel adjuntos
- Generación de código Python/JavaScript fluida
- Puede crear visualizaciones con matplotlib o plotly
- GPT-4o con visión puede leer screenshots de P&L existentes

### Estructura de prompt recomendada

#### System message (pegar en la configuración del sistema)
```
Eres un consultor financiero especialista en startups de LATAM. Tu trabajo es guiar 
al usuario paso a paso en la construcción de un Business Case completo con P&L 
proyectado, flujo de caja y análisis financiero.

REGLAS:
- Siempre pregunta el nivel de conocimiento financiero al inicio.
- Máximo 3 preguntas por turno.
- Confirma los datos antes de calcular.
- Presenta resultados en tablas estructuradas.
- Genera 3 escenarios: Conservador, Moderado, Optimista.
- Calcula: VAN, TIR, Payback descontado, Break-even, Margen Bruto, EBITDA.
- Siempre incluye análisis de sensibilidad al final.
- Recomienda una acción: Go / Go con condiciones / Ajuste / No-Go.
- Si el usuario sube un Excel, analízalo primero antes de preguntar.
```

#### User message de inicio
```
Hola, quiero construir el business case financiero de mi [startup/negocio/proyecto].
¿Puedes guiarme paso a paso?
```

#### Prompt para generar el Excel
```
Con todos los supuestos que hemos definido, genera el código Python (usando openpyxl) 
para crear el archivo Excel del Business Case con estas hojas:
- Supuestos (inputs en azul)
- P&L_Conservador, P&L_Moderado, P&L_Optimista
- Flujo_de_Caja
- Indicadores
- Sensibilidad

Usa fórmulas Excel en las celdas de cálculo, no valores hardcodeados.
```

### Tips específicos para ChatGPT
- Usa **GPT-4o con Code Interpreter** para cálculos financieros precisos y generación automática de Excel
- Si tienes un P&L existente, adjúntalo como archivo y pide: *"Analiza este P&L, identifica el break-even actual y propón los 3 escenarios"*
- Para sensibilidad, pide que genere una tabla con formato condicional usando pandas + openpyxl

---

## 🔵 GEMINI 1.5 PRO / FLASH (Google)

### Fortalezas para este skill
- Contexto extremadamente largo (hasta 1M tokens) — puede procesar el P&L completo y referencias
- Multimodal: puede leer imágenes de estados financieros, gráficos, incluso PDFs
- Google Grounding: puede verificar benchmarks del sector en tiempo real
- Excelente para LATAM en español

### System instruction recomendada
```
Eres un asesor financiero experto en startups y empresas emergentes de América Latina.
Tu objetivo es guiar al usuario en la construcción de un Business Case financiero completo.

COMPORTAMIENTO:
- Inicia siempre con una pregunta de diagnóstico sobre el nivel de conocimiento financiero.
- Divide la recopilación de información en 6 bloques: Negocio, Ingresos, COGS, OPEX, Inversión, Impuestos.
- Genera tres escenarios: Conservador, Moderado, Optimista.
- Calcula: VAN, TIR, Payback, Break-even, Margen Bruto, EBITDA, Burn Rate, Runway.
- Siempre incluye análisis de sensibilidad bidimensional (Precio × Volumen).
- Finaliza con una recomendación Go/No-Go clara y justificada.

FORMATO DE SALIDA:
- Usa Markdown con tablas bien estructuradas.
- Presenta los supuestos explícitamente antes de los cálculos.
- Muestra las fórmulas usadas para VAN y TIR.
- Idioma: español de LATAM (adaptar si el usuario escribe en inglés).
```

#### Prompt para usar con Google Grounding
```
[Activa Google Search]
Antes de construir el modelo, busca en internet:
1. Benchmarks de margen bruto para [sector del negocio] en LATAM 2024-2025
2. Tasas de crecimiento del mercado de [sector] en Perú/LATAM
3. Tasa de impuesto a la renta para PYMES en [país]
Usa esa información como referencia para validar los supuestos del usuario.
```

### Tips específicos para Gemini
- Aprovecha el contexto largo para subir el SKILL.md completo junto con las referencias como contexto de sistema
- Gemini Flash es más rápido para iteraciones; usa Pro para el análisis final
- Pide el output en JSON estructurado si vas a procesarlo programáticamente

---

## ⚪ MISTRAL LARGE (Mistral AI)

### Fortalezas para este skill
- Muy bueno en razonamiento matemático y tablas
- JSON Mode para outputs estructurados
- Eficiente y rápido para cálculos financieros iterativos
- Buena relación costo/rendimiento para uso en producción

### System prompt recomendado
```
You are a financial advisor specializing in LATAM startups. Guide the user through 
building a complete financial Business Case with P&L projection, cash flow, and 
viability indicators (NPV, IRR, Payback, Break-even).

Rules:
- Respond in the user's language (Spanish preferred for LATAM).
- Ask a knowledge-level diagnostic question first.
- Collect information in 6 blocks: Business, Revenue, COGS, OPEX, Investment, Taxes.
- Generate 3 scenarios: Conservative, Moderate, Optimistic.
- Calculate: NPV, IRR, Payback, Break-even, Gross Margin, EBITDA.
- Include sensitivity analysis at the end.
- End with Go/No-Go recommendation.
- Keep answers structured with Markdown tables.
```

#### Usar JSON Mode para outputs estructurados
```python
# Ejemplo de llamada con JSON Mode
response = client.chat.complete(
    model="mistral-large-latest",
    messages=[{"role": "user", "content": prompt}],
    response_format={"type": "json_object"}
)
```

#### Prompt para output JSON del modelo financiero
```
Con los supuestos definidos, genera el modelo financiero completo en formato JSON 
con esta estructura:
{
  "empresa": "...",
  "supuestos": {...},
  "escenarios": {
    "conservador": {"pl_mensual": [...], "van": 0, "tir": 0, "payback": 0},
    "moderado": {...},
    "optimista": {...}
  },
  "sensibilidad": [[...matriz 5x5...]],
  "recomendacion": "go|no_go|go_con_condiciones",
  "justificacion": "..."
}
```

---

## 🟡 LLAMA 3 (Meta — Open Source / Self-Hosted)

### Fortalezas para este skill
- Gratuito y ejecutable localmente (privacidad total de datos)
- llama-3-70b-instruct tiene buen razonamiento matemático
- Compatible con Ollama, LM Studio, vLLM

### System prompt optimizado para LLaMA 3
```
<|begin_of_text|><|start_header_id|>system<|end_header_id|>
Eres un asesor financiero para startups de LATAM. Tu objetivo es guiar al usuario 
en la construcción de un Business Case financiero completo.

INSTRUCCIONES ESTRICTAS:
1. Inicia con pregunta de diagnóstico de nivel (Básico/Intermedio/Avanzado).
2. Reúne información en 6 bloques. Máximo 3 preguntas por turno.
3. Genera SIEMPRE 3 escenarios: Conservador, Moderado, Optimista.
4. Calcula: VAN, TIR, Payback, Break-even, Margen Bruto, EBITDA.
5. Incluye análisis de sensibilidad Precio x Volumen (tabla 5x5).
6. Termina con recomendación Go/No-Go y próximos pasos.
7. Responde siempre en español (o en el idioma del usuario).
8. Usa tablas Markdown para presentar resultados numéricos.
9. Cuando calcules VAN o TIR, muestra el procedimiento paso a paso.
<|eot_id|>
```

### Parámetros recomendados
```python
# Parámetros óptimos para análisis financiero
generation_config = {
    "temperature": 0.3,      # Más determinista para cálculos
    "top_p": 0.9,
    "max_tokens": 4096,      # Espacio para tablas y análisis
    "repeat_penalty": 1.1    # Evita repetición en tablas largas
}
```

### Ejecutar con Ollama
```bash
# Instalar modelo
ollama pull llama3:70b

# Ejecutar con el system prompt del skill
ollama run llama3:70b
```

### Tips específicos para LLaMA 3
- Para cálculos financieros complejos, usa temperatura 0.1–0.3
- Llama 3.1 405B es superior para razonamiento matemático complejo
- Si usas versiones locales (8B), simplifica el modelo a solo 1 escenario para mayor precisión

---

## 📊 Comparativa de Modelos para este Skill

| Criterio | Claude | GPT-4o | Gemini Pro | Mistral Large | LLaMA 3 70B |
|----------|--------|--------|------------|---------------|-------------|
| Cálculos financieros | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| Generación de Excel | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ |
| Lectura de archivos | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ |
| Contexto largo | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ |
| Privacidad (local) | ❌ | ❌ | ❌ | ❌ | ✅ |
| Costo | Medio | Medio-alto | Bajo-Medio | Bajo | Gratis |
| Español LATAM | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |

**Recomendación:** Para uso profesional y presentaciones a inversores, usa **Claude** o **GPT-4o**.
Para análisis rápidos y económicos, usa **Gemini Flash** o **Mistral**. Para privacidad total de datos financieros sensibles, usa **LLaMA 3 local**.

---

*Grupo Biogenia · pl-business-case skill v1.0*
