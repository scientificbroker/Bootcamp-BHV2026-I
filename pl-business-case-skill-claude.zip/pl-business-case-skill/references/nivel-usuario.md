# Guía de Adaptación por Nivel del Usuario

---

## 🌱 Nivel BÁSICO

### Perfil
- Emprendedor/a con idea o negocio naciente
- No usa Excel regularmente
- Conoce sus ventas aproximadas pero no lleva registros formales
- No ha escuchado términos como VAN, TIR, EBITDA

### Estilo de comunicación
- Usa analogías cotidianas: *"El margen bruto es como lo que te queda después de pagar lo que costó hacer el producto"*
- Evita siglas sin explicarlas
- Usa emojis y ejemplos numéricos concretos
- Pregunta en términos de "dinero que entra" y "dinero que sale"
- Celebra cuando el usuario entiende algo: *"Exacto, eso es el punto de equilibrio"*

### Preguntas adaptadas
En lugar de: *"¿Cuál es tu COGS como % del precio de venta?"*  
Pregunta: *"¿Cuánto te cuesta producir o conseguir una unidad de lo que vendes? Por ejemplo, si vendes a S/ 50, ¿cuánto gastaste para tenerlo listo para vender?"*

En lugar de: *"¿Cuál es tu tasa de descuento o WACC?"*  
Pregunta: *"Si no hubieras puesto ese dinero en tu negocio, ¿dónde lo habrías puesto? ¿Un plazo fijo, un fondo mutuo? Eso nos ayuda a calcular si tu negocio vale más que esa alternativa."*

### Indicadores a mostrar (priorizar)
1. Break-even (cuánto debo vender para no perder)
2. Payback (cuándo recupero mi inversión)
3. Margen bruto (% que me queda después de costos directos)
4. Runway (cuánto tiempo aguanta el negocio con la caja actual)

### Presentación de resultados
- Usa cuadros simples y comparaciones relativas
- Siempre redondea a cifras enteras
- Incluye frases de interpretación: *"Con este escenario conservador, necesitarías vender al menos 80 unidades al mes para no perder dinero"*

---

## 🌿 Nivel INTERMEDIO

### Perfil
- Lleva o ha llevado algún registro de ventas y gastos
- Entiende conceptos básicos: costos fijos, costos variables, margen
- Ha proyectado ventas informalmente
- Puede leer una hoja de cálculo básica

### Estilo de comunicación
- Puede usar términos como: margen, COGS, flujo de caja, EBITDA (con definición rápida)
- Mezcla lenguaje técnico con explicaciones claras
- Muestra fórmulas pero también el significado
- Usa tablas y comparaciones numéricas

### Preguntas adaptadas
Puede preguntar directamente:
- *"¿Tienes estimado cuánto te cuesta producir cada unidad? (Costo Variable Unitario)"*
- *"¿Cuáles son tus costos fijos mensuales? (Los que pagas aunque no vendas nada)"*
- *"¿Qué rentabilidad mínima esperarías de esta inversión?"*

### Indicadores a mostrar (todos)
VAN, TIR, Payback, Break-even, Margen Bruto, EBITDA, Burn Rate, Runway

### Presentación de resultados
- Tablas comparativas de los 3 escenarios
- Análisis de sensibilidad simplificado (3×3)
- Explicación de qué palanca tiene más impacto en el resultado

---

## 🌳 Nivel AVANZADO

### Perfil
- Gestiona finanzas profesionalmente o tiene formación en negocios
- Conoce EBITDA, VAN, TIR, WACC, DCF, múltiplos de valuación
- Puede tener estados financieros existentes o proyecciones previas
- Quiere refinar el modelo, no aprender desde cero

### Estilo de comunicación
- Usa terminología financiera completa sin definiciones básicas
- Puede presentar alternativas metodológicas (ej: usar FCF vs FCFE)
- Muestra supuestos explícitos y sensibilidades
- Puede discutir sobre la tasa de descuento (WACC, CAPM, risk premium)

### Preguntas adaptadas
- *"¿Usas una tasa de descuento ya definida o quieres que calculemos el WACC?"*
- *"¿Quieres modelar el capital de trabajo dinámicamente o usamos días de cobro/pago fijos?"*
- *"¿Incluimos valor terminal en el horizonte de proyección?"*

### Indicadores adicionales para avanzados
- **WACC** (si tiene deuda y capital propio)
- **EV/EBITDA múltiplo** de salida (para pitch a inversores)
- **Valor Terminal** (perpetuidad con Gordon Growth Model)
- **MOIC** (Multiple on Invested Capital) si hay inversores
- **LTV/CAC ratio** si es SaaS o modelo de suscripción

### Presentación de resultados
- Análisis de sensibilidad completo (5×5)
- Waterfall de valor (cómo cada supuesto contribuye al VAN)
- Comparación con benchmarks del sector
- Recomendación estratégica con alternativas

---

## Detección automática de nivel

Si el usuario no responde la pregunta de diagnóstico, infiere el nivel por:
- Vocabulario usado en su mensaje inicial
- Si adjunta archivos (Excel, PDF) → probablemente Intermedio/Avanzado
- Si describe su negocio informalmente → probablemente Básico
- Si menciona VAN, TIR, EBITDA → Avanzado

**Default seguro:** Empieza en Intermedio y ajusta según las respuestas.

---

*Grupo Biogenia · pl-business-case skill v1.0*
