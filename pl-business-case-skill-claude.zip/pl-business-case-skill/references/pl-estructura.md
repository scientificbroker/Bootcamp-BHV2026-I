# Estructura del P&L — Referencia por Línea

> Basado en el modelo MICROFUDS CRM · Adaptado para startups y servicios profesionales

---

## I. INGRESOS

### Líneas de ingreso admitidas (hasta 5)
| Línea | Descripción | Ejemplo |
|-------|-------------|---------|
| `Ventas Producto 1` | Producto o servicio principal | Poppings Boba Arándano |
| `Ventas Producto 2` | Segunda línea (opcional) | Consultoría / Transferencia |
| `Otros Ingresos` | Ingresos no operativos recurrentes | Comisiones, licencias |
| `(-) Descuentos y devoluciones` | Siempre negativo; % sobre ventas brutas | 3-8% típico en B2B |

**Fórmulas clave:**
```
Ventas Brutas = Σ(Precio_unitario × Unidades_vendidas)
Ventas Netas  = Ventas Brutas − Descuentos − Devoluciones
```

### Parámetros de crecimiento por tipo de negocio
| Tipo | Crecimiento mensual conservador | Moderado | Optimista |
|------|---------------------------------|----------|-----------|
| Producto físico B2B | 3% | 8% | 15% |
| SaaS / Suscripción | 5% | 12% | 25% |
| Servicio profesional | 2% | 6% | 12% |
| Marketplace | 4% | 10% | 20% |
| Alimentos / FoodTech | 5% | 10% | 18% |

---

## II. COSTO DE VENTAS (COGS)

### Subcategorías estándar
| Línea | Descripción | Tip |
|-------|-------------|-----|
| `Materia prima` | Insumos directos del producto | Expresar como % del precio de venta |
| `Materiales de empaque` | Envases, etiquetas, cajas | Incluir solo si aplica |
| `Maquila / Producción` | Tercerización de fabricación | Si producción propia, usar nómina de producción |
| `Control de calidad` | Pruebas, certificaciones, mermas | Puede ser fijo o variable |
| `Costo de entrega / logística` | Flete, last mile | Incluir si se absorbe |
| `Costo de adquisición (CAC)` | Solo para SaaS/Marketplace | Google Ads, Meta Ads atribuibles |

**Fórmulas clave:**
```
COGS Total    = Σ(Costos variables directos)
Utilidad Bruta = Ventas Netas − COGS Total
Margen Bruto  = Utilidad Bruta / Ventas Netas × 100
```

### Benchmarks de Margen Bruto por sector
| Sector | Margen Bruto esperado |
|--------|-----------------------|
| FoodTech / Alimentos procesados | 35–55% |
| SaaS | 65–85% |
| Servicio profesional | 55–75% |
| Retail / Distribución | 20–40% |
| Manufactura | 30–50% |

---

## III. GASTOS OPERATIVOS (OPEX)

### Subcategorías estándar
| Línea | Descripción | Frecuencia |
|-------|-------------|-----------|
| `Honorarios / Nómina` | Fundadores + equipo | Mensual fijo |
| `Pasajes y viáticos` | Ventas, visitas, reuniones | Variable |
| `Marketing y redes sociales` | Pauta, community, diseño | Mensual |
| `Servicios básicos` | Agua, luz, internet, hosting | Mensual fijo |
| `Depreciación de equipos` | CAPEX / vida útil en meses | Mensual fijo |
| `Alquiler / Coworking` | Oficina, almacén, laboratorio | Mensual fijo |
| `Legales y contables` | Contador, notario, registros | Mensual o puntual |
| `Otros gastos admin.` | Imprevistos, suscripciones | ~5-10% del OPEX |

**Fórmulas clave:**
```
OPEX Total         = Σ(Gastos operativos del período)
Utilidad Operativa = Utilidad Bruta − OPEX Total
EBITDA (aprox.)    = Utilidad Operativa + Depreciación
Margen EBITDA      = EBITDA / Ventas Netas × 100
```

---

## IV. OTROS INGRESOS / GASTOS

| Línea | Descripción |
|-------|-------------|
| `Ingresos financieros` | Rendimientos, fondos semilla prorrateados, grants |
| `Gastos financieros` | Intereses de préstamos, comisiones bancarias |
| `Diferencia cambiaria` | Solo si opera en moneda extranjera |

```
Utilidad Antes de Impuestos (UAI) = EBITDA − Depreciación + Otros ingresos − Gastos financieros
```

---

## V. IMPUESTOS

### Regímenes tributarios (Perú — referencia LATAM)
| Régimen | Tasa IR aplicable | Límite ingresos |
|---------|-------------------|----------------|
| RUS | Cuota fija S/ 20-50 | Hasta S/ 96,000/año |
| RMT | 1.5% sobre ingresos netos (mínimo) | Hasta 1,700 UIT |
| MYPE Tributario | 10% hasta 15 UIT de utilidad | Hasta 1,700 UIT |
| General | 29.5% sobre utilidad neta | Sin límite |

**Nota:** Si el usuario está en pérdida, Impuesto = 0 (en la mayoría de regímenes).

```
Utilidad Neta  = UAI − Impuesto a la Renta
Margen Neto    = Utilidad Neta / Ventas Netas × 100
```

---

## Flujo de Caja Libre (FCL)

```
FCL = Utilidad Neta 
    + Depreciación (no es salida de caja) 
    − Variación Capital de Trabajo (∆CxC − ∆Inventario + ∆CxP) 
    − CAPEX del período
```

### Capital de Trabajo (referencia)
| Variable | Días típicos startup |
|----------|---------------------|
| Días de cobro (CxC) | 15–45 días |
| Días de inventario | 15–30 días |
| Días de pago a proveedores (CxP) | 15–30 días |

---

## Período de proyección recomendado

| Etapa del negocio | Horizonte P&L | Período FCL para VAN/TIR |
|-------------------|---------------|--------------------------|
| Pre-revenue / Idea | 24 meses | 36–48 meses |
| Early stage (< 1 año) | 18 meses | 36 meses |
| Growth stage (1-3 años) | 12 meses | 24–36 meses |
| Expansión / Scale-up | 12 meses | 24 meses |

---

*Grupo Biogenia · pl-business-case skill v1.0*
