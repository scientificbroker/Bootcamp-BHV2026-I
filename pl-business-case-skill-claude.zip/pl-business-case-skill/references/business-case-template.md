# Plantilla de Business Case — Estructura y Contenido

---

## Portada

```
══════════════════════════════════════════════════════
            BUSINESS CASE — ANÁLISIS DE VIABILIDAD
══════════════════════════════════════════════════════

Empresa / Proyecto:  [Nombre]
Industria:           [Sector]
Fecha:               [DD/MM/AAAA]
Preparado por:       [Nombre del fundador/analista]
Versión:             v1.0

Confidencial — Solo para uso interno y presentaciones autorizadas
══════════════════════════════════════════════════════
```

---

## Sección 1 — Resumen Ejecutivo (Executive Summary)

**Extensión:** Máximo 1 página / 300 palabras

Incluir:
- **Oportunidad identificada:** ¿Qué problema resuelve y para quién?
- **Propuesta de valor:** ¿Por qué tu solución es diferente/mejor?
- **Inversión requerida:** Total en S/ o USD, origen del capital
- **Retorno esperado:** VAN y TIR en escenario moderado
- **Período de recuperación:** Payback en meses
- **Decisión solicitada:** Go / No-Go / Necesita financiamiento adicional

**Frases de apertura sugeridas:**
> "[Empresa] es una startup de [sector] que resuelve [problema] para [segmento]. Con una inversión inicial de [monto], proyectamos una TIR de [X]% anual y recuperación en [Y] meses bajo el escenario base. Solicitamos [decisión]."

---

## Sección 2 — Descripción del Negocio

| Campo | Contenido |
|-------|-----------|
| Nombre | |
| Sector / Industria | |
| Año de fundación | |
| Etapa actual | Pre-revenue / Early stage / Growth / Expansión |
| Modelo de ingresos | Venta directa / Suscripción / Comisión / Mixto |
| Mercado objetivo | Descripción del segmento (B2B / B2C / B2G) |
| Tamaño de mercado (TAM/SAM/SOM) | Si está disponible |
| Propuesta de valor | 1-2 oraciones |
| Canales de venta | |
| Ventaja competitiva | |
| Estado legal / Régimen tributario | |

---

## Sección 3 — Supuestos del Modelo

Presenta siempre los supuestos antes de los números. El lector debe poder reproducir el modelo.

### Tabla de supuestos clave
| Supuesto | Valor | Fuente / Justificación |
|----------|-------|------------------------|
| Precio de venta (Producto 1) | S/ | Benchmark de mercado / precio actual |
| Precio de venta (Producto 2) | S/ | |
| Crecimiento mensual de ventas | % | Tendencia histórica / benchmark sector |
| COGS como % de ventas | % | Cotizaciones / estructura de costos |
| Nómina mensual total | S/ | Honorarios actuales + proyectados |
| Tasa de descuento (anual) | % | Costo de oportunidad / WACC |
| Inversión inicial (CAPEX) | S/ | Cotizaciones / inversión ya realizada |
| Días de cobro (CxC) | Días | Política comercial |
| Días de pago a proveedores | Días | Negociación con proveedores |
| Régimen tributario | | RUS / RMT / MYPE / General |
| Tasa de impuesto | % | Según régimen |
| Horizonte de proyección | Meses | |

### Nota sobre los escenarios
> Los escenarios Conservador, Moderado y Optimista varían los supuestos de crecimiento, precio y costos según la tabla en la Sección 5. El escenario Moderado representa el caso base.

---

## Sección 4 — Estado de Resultados Proyectado (P&L)

Presenta la tabla de P&L para los 12 meses en el escenario **Moderado** (base).
Las tablas de los tres escenarios van en el Excel adjunto.

```
                    M1    M2    M3    M4    M5    M6    M7    M8    M9   M10   M11   M12   TOTAL
I. INGRESOS
  Ventas Brutas
  (-) Descuentos
  VENTAS NETAS

II. COGS
  [Línea 1]
  [Línea 2]
  COGS TOTAL
  UTILIDAD BRUTA
  Margen Bruto %

III. OPEX
  Nómina / Honorarios
  Marketing
  Servicios
  Depreciación
  Otros
  OPEX TOTAL
  UTILIDAD OPERATIVA
  Margen EBITDA %

IV. OTROS
  Ingresos financieros
  Gastos financieros
  UTILIDAD ANTES IMPUESTOS
  Impuesto a la Renta
  UTILIDAD NETA
  Margen Neto %
```

---

## Sección 5 — Flujo de Caja Libre

```
                    M1    M2    M3    ...    M12   TOTAL
Utilidad Neta
(+) Depreciación
(-) CAPEX
(+/-) ∆ Capital de Trabajo
FLUJO DE CAJA LIBRE (FCL)
FCL Acumulado
FCL Descontado
FCL Descontado Acumulado
```

---

## Sección 6 — Indicadores de Viabilidad

### Tabla resumen de los 3 escenarios
```
┌─────────────────────────┬──────────────┬──────────────┬──────────────┐
│ Indicador               │ 🔵 Conserv.  │ 🟡 Moderado  │ 🟢 Optimista │
├─────────────────────────┼──────────────┼──────────────┼──────────────┤
│ VAN (S/)                │              │              │              │
│ TIR (% anual)           │              │              │              │
│ Payback (meses)         │              │              │              │
│ Break-even (unid./mes)  │              │              │              │
│ Break-even (S//mes)     │              │              │              │
│ Margen Bruto Año 1 (%)  │              │              │              │
│ Margen EBITDA Año 1 (%) │              │              │              │
│ Burn Rate prom. (S//mes)│              │              │              │
│ Runway inicial (meses)  │              │              │              │
└─────────────────────────┴──────────────┴──────────────┴──────────────┘
```

### Interpretación
Para cada indicador, incluir 1-2 oraciones de interpretación:
- ¿El VAN es positivo? → ¿Bajo qué condiciones?
- ¿La TIR supera el costo de capital?
- ¿El payback es razonable para el sector?

---

## Sección 7 — Análisis de Sensibilidad

### Tabla bidimensional: VAN según Precio × Volumen

```
                Volumen −20%  −10%    BASE    +10%    +20%
Precio +20%
Precio +10%
BASE
Precio −10%
Precio −20%
```

🟢 = VAN > 0 (viable)   🔴 = VAN < 0 (inviable)   🟡 = VAN ≈ 0 (umbral)

### Interpretación de la sensibilidad
- ¿A cuál variable es más sensible el VAN?
- ¿Cuál es la combinación mínima para ser viable?
- ¿Qué palanca estratégica tiene más impacto?

---

## Sección 8 — Riesgos y Plan de Mitigación

| N° | Riesgo | Probabilidad | Impacto | Estrategia de mitigación |
|----|--------|-------------|---------|--------------------------|
| 1 | | Alta/Media/Baja | Alto/Medio/Bajo | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |

### Riesgos típicos por tipo de negocio a considerar
- **Producto físico:** Quiebre de stock, alza de insumos, retrasos en producción
- **SaaS:** Churn elevado, CAC creciente, competencia de plataformas grandes
- **Servicio profesional:** Dependencia de clientes clave, pérdida de talento
- **Foodtech / Alimentos:** Regulación sanitaria, estacionalidad, logística de cadena de frío

---

## Sección 9 — Conclusión y Recomendación

### Estructura recomendada

1. **Síntesis de resultados** (2-3 oraciones): qué dicen los números
2. **Condiciones de viabilidad**: qué debe cumplirse para que funcione
3. **Decisión recomendada** (elegir una):
   - ✅ **GO** — Proceder con la inversión bajo el escenario moderado
   - ⚠️ **GO con condiciones** — Proceder si se logra [X] antes de [fecha]
   - 🔄 **Ajuste estratégico** — Revisar [supuesto clave] antes de invertir
   - ❌ **NO-GO** — El modelo no es viable bajo los supuestos actuales
4. **Próximos pasos** (lista de 3-5 acciones concretas con responsable y fecha)

---

## Anexos (opcionales)

- **Anexo A:** Tablas completas del P&L para los 3 escenarios
- **Anexo B:** Detalle del cálculo del WACC (si aplica)
- **Anexo C:** Benchmarks del sector comparados
- **Anexo D:** CV del equipo fundador
- **Anexo E:** Cotizaciones, contratos o MOUs relevantes

---

*Grupo Biogenia · pl-business-case skill v1.0*
