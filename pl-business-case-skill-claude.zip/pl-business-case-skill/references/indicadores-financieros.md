# Indicadores Financieros de Viabilidad — Fórmulas y Guía de Interpretación

---

## 1. VAN — Valor Actual Neto (NPV)

### Fórmula
```
VAN = −Inversión_Inicial + Σ [ FCLₜ / (1 + r)ᵗ ]

Donde:
  FCLₜ  = Flujo de Caja Libre del período t
  r     = Tasa de descuento (mensual si el flujo es mensual)
  t     = Período (1, 2, 3, ... n)
  n     = Horizonte de proyección en períodos
```

### Conversión de tasa anual a mensual
```
r_mensual = (1 + r_anual)^(1/12) − 1
Ejemplo: 12% anual → (1.12)^(1/12) − 1 = 0.949% mensual
```

### Interpretación
| VAN | Decisión |
|-----|----------|
| > 0 | ✅ El proyecto crea valor. Viable financieramente. |
| = 0 | ⚠️ Recupera exactamente la inversión. Evaluar riesgo. |
| < 0 | ❌ El proyecto destruye valor a esta tasa. Revisar supuestos. |

### Tasas de descuento de referencia (LATAM 2024-2025)
| Tipo de negocio | Tasa de descuento sugerida |
|-----------------|---------------------------|
| Startup etapa temprana (alto riesgo) | 25–35% anual |
| PYME con trayectoria | 15–20% anual |
| Negocio establecido / bajo riesgo | 10–15% anual |
| Con financiamiento bancario | Usar WACC |
| Default conservador (Perú) | 20% anual |

---

## 2. TIR — Tasa Interna de Retorno (IRR)

### Definición
La TIR es la tasa de descuento que hace que el VAN sea igual a cero.
```
0 = −Inversión_Inicial + Σ [ FCLₜ / (1 + TIR)ᵗ ]
```
No tiene fórmula cerrada; se resuelve iterativamente (Excel: `=TIR()` / `=IRR()`).

### Cálculo aproximado con el método de interpolación
```
TIR ≈ r₁ + [VAN₁ / (VAN₁ − VAN₂)] × (r₂ − r₁)

Donde r₁ da VAN positivo y r₂ da VAN negativo.
```

### Interpretación
| Comparación TIR vs Tasa de descuento | Decisión |
|---------------------------------------|----------|
| TIR > Tasa de descuento | ✅ El proyecto es atractivo |
| TIR = Tasa de descuento | ⚠️ Umbral mínimo |
| TIR < Tasa de descuento | ❌ No es rentable a este costo de capital |

### Benchmarks TIR por tipo de inversor
| Tipo de inversor | TIR mínima esperada |
|------------------|---------------------|
| Angel Investor / Aceleradoras | 30–50% anual |
| Capital de Riesgo (VC) | 25–40% anual |
| Fondos de impacto / LATAM | 15–25% anual |
| Banco / financiamiento formal | 12–20% anual |
| Inversionista familiar | 10–15% anual |

---

## 3. Payback — Período de Recuperación

### Simple (sin descuento)
```
Payback = Inversión Inicial / Flujo de Caja Promedio Anual
```

### Descontado (recomendado)
```
Payback Descontado = Período en que el FCL acumulado descontado = Inversión Inicial
```
Se calcula acumulando el FCL descontado mes a mes hasta que cruce cero.

### Interpolación para precisión mensual
```
Payback = n + |FCL_acum(n)| / FCL_descontado(n+1)
Donde n = último período con FCL acumulado negativo
```

### Interpretación por horizonte
| Payback | Valoración |
|---------|-----------|
| < 12 meses | ✅ Excelente — recuperación rápida |
| 12–24 meses | ✅ Bueno — aceptable para startups |
| 24–36 meses | ⚠️ Moderado — revisar estructura de costos |
| > 36 meses | ❌ Alto riesgo — reconsiderar modelo |

---

## 4. Break-Even — Punto de Equilibrio

### En unidades
```
Break-Even (unidades) = Costos Fijos Totales / (Precio de Venta − Costo Variable Unitario)
```

### En ventas ($)
```
Break-Even (S/) = Costos Fijos Totales / Margen de Contribución (%)
Margen de Contribución (%) = (Precio − CVU) / Precio
```

### Dinámico mensual
Para modelos con costos variables:
```
Break-Even_mes = OPEX_mes / Margen_Bruto_mes
```

### Ejemplo de presentación
```
📍 Con tus datos:
   Costos fijos mensuales: S/ 3,800
   Precio promedio:        S/ 45
   Costo variable unitario: S/ 22
   Margen de contribución: S/ 23/unidad (51%)
   
   Break-even = 3,800 / 23 = 165 unidades/mes
   Break-even = S/ 7,451/mes en ventas
```

---

## 5. Margen Bruto

```
Margen Bruto (%) = (Ventas Netas − COGS) / Ventas Netas × 100
```

---

## 6. EBITDA y Margen EBITDA

```
EBITDA = Utilidad Operativa + Depreciación + Amortización
Margen EBITDA (%) = EBITDA / Ventas Netas × 100
```

---

## 7. Burn Rate y Runway (para startups pre-revenue o con pérdidas)

```
Burn Rate = Egresos Totales Mensuales − Ingresos Mensuales
          = Pérdida neta mensual (si negativa)

Runway (meses) = Caja Disponible / Burn Rate mensual promedio
```

### Semáforo de Runway
| Runway | Alerta |
|--------|--------|
| > 18 meses | 🟢 Seguro |
| 12–18 meses | 🟡 Buscar financiamiento |
| 6–12 meses | 🟠 Urgente — buscar runway adicional |
| < 6 meses | 🔴 Crisis — pivote o cierre inminente |

---

## 8. Análisis de Sensibilidad — Matriz Bidimensional

### Cómo construirla
1. Seleccionar 2 variables críticas (normalmente: **precio** y **volumen**)
2. Definir rangos: −20%, −10%, base, +10%, +20%
3. Calcular VAN para cada combinación
4. Colorear: 🟢 VAN > 0 / 🔴 VAN < 0 / 🟡 VAN ≈ 0

### Plantilla de tabla (en texto)
```
                  Volumen −20%  Volumen −10%   BASE    Volumen +10%  Volumen +20%
Precio +20%       [VAN]         [VAN]          [VAN]   [VAN]         [VAN]
Precio +10%       [VAN]         [VAN]          [VAN]   [VAN]         [VAN]
Precio BASE       [VAN]         [VAN]          [VAN]   [VAN]         [VAN]
Precio −10%       [VAN]         [VAN]          [VAN]   [VAN]         [VAN]
Precio −20%       [VAN]         [VAN]          [VAN]   [VAN]         [VAN]
```

### Variables alternativas para el eje X/Y
- Eje X: Crecimiento mensual (en lugar de precio)
- Eje Y: % COGS (en lugar de volumen)
- Para SaaS: Churn rate vs. CAC

---

## 9. Resumen de Indicadores — Tabla de Presentación

Al final del análisis, presenta siempre esta tabla:

```
┌─────────────────────────┬──────────────┬──────────────┬──────────────┐
│ Indicador               │ Conservador  │  Moderado    │  Optimista   │
├─────────────────────────┼──────────────┼──────────────┼──────────────┤
│ VAN (S/)                │              │              │              │
│ TIR (% anual)           │              │              │              │
│ Payback (meses)         │              │              │              │
│ Break-even (unid./mes)  │              │              │              │
│ Break-even (S//mes)     │              │              │              │
│ Margen Bruto (%)        │              │              │              │
│ Margen EBITDA (%)       │              │              │              │
│ Burn Rate (S//mes)      │              │              │              │
│ Runway (meses)          │              │              │              │
└─────────────────────────┴──────────────┴──────────────┴──────────────┘
```

---

*Grupo Biogenia · pl-business-case skill v1.0*
