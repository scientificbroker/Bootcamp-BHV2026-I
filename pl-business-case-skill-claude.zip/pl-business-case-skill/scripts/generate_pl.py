"""
generate_pl.py — Generador de Business Case P&L en Excel
Grupo Biogenia · pl-business-case skill v1.0

Uso:
    python3 generate_pl.py

Edita la sección SUPUESTOS antes de ejecutar, o importa como módulo
y llama a generate_business_case(config) con un diccionario de configuración.

Dependencias:
    pip install openpyxl --break-system-packages
"""

import json
import math
from datetime import datetime
from pathlib import Path

try:
    import openpyxl
    from openpyxl import Workbook
    from openpyxl.styles import (
        Font, PatternFill, Alignment, Border, Side, numbers
    )
    from openpyxl.utils import get_column_letter
except ImportError:
    print("Instalando openpyxl...")
    import subprocess, sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "openpyxl",
                           "--break-system-packages", "-q"])
    import openpyxl
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter


# ─────────────────────────────────────────────────
# SUPUESTOS — Editar esta sección con los datos reales
# ─────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "empresa": "Mi Startup",
    "sector": "FoodTech / Alimentos",
    "pais": "Peru",
    "moneda": "S/",
    "fecha": datetime.now().strftime("%Y-%m"),
    "horizonte_meses": 12,

    # Inversión inicial
    "inversion_inicial": 15000,
    "caja_inicial": 5000,

    # Tasa de descuento anual (default 20% para LATAM startup)
    "tasa_descuento_anual": 0.20,

    # Líneas de ingreso (hasta 5)
    "lineas_ingreso": [
        {"nombre": "Producto Principal", "precio": 45.0, "unidades_m1": 80},
        {"nombre": "Servicio / Consultoría", "precio": 500.0, "unidades_m1": 1},
    ],

    # Crecimiento mensual de ventas por escenario
    "crecimiento_mensual": {
        "conservador": 0.05,
        "moderado": 0.10,
        "optimista": 0.18,
    },

    # Descuentos sobre ventas brutas (%)
    "pct_descuentos": {
        "conservador": 0.08,
        "moderado": 0.05,
        "optimista": 0.03,
    },

    # COGS como % de ventas brutas
    "pct_cogs": {
        "conservador": 0.55,
        "moderado": 0.48,
        "optimista": 0.40,
    },

    # Desglose del COGS (suma debe = 1.0)
    "cogs_desglose": {
        "Materia Prima": 0.65,
        "Materiales de Empaque": 0.15,
        "Maquila / Producción": 0.15,
        "Control de Calidad": 0.05,
    },

    # Gastos Operativos mensuales (fijos base)
    "opex_fijo": {
        "Honorarios / Nómina": 3000,
        "Pasajes y Viáticos": 300,
        "Marketing y Redes": 200,
        "Servicios (agua, luz, internet)": 120,
        "Depreciación Equipos": 100,
        "Alquiler / Coworking": 500,
        "Otros Gastos Admin.": 80,
    },

    # Variación del OPEX por escenario (multiplicador)
    "opex_multiplicador": {
        "conservador": 1.10,
        "moderado": 1.00,
        "optimista": 0.95,
    },

    # Impuesto a la Renta (tasa efectiva)
    "tasa_ir": 0.015,  # 1.5% RMT Perú (sobre ventas si hay utilidad)
    "regimen": "RMT",

    # Días de capital de trabajo
    "dias_cobro": 30,
    "dias_inventario": 20,
    "dias_pago": 30,
}


# ─────────────────────────────────────────────────
# ESTILOS
# ─────────────────────────────────────────────────
def _style():
    return {
        "header_fill": PatternFill("solid", fgColor="1F3864"),  # Azul marino
        "header_font": Font(bold=True, color="FFFFFF", name="Arial", size=11),
        "section_fill": PatternFill("solid", fgColor="2E74B5"),
        "section_font": Font(bold=True, color="FFFFFF", name="Arial", size=10),
        "input_font": Font(color="0000FF", name="Arial", size=10),   # Azul = inputs
        "formula_font": Font(color="000000", name="Arial", size=10), # Negro = fórmulas
        "positive_fill": PatternFill("solid", fgColor="C6EFCE"),
        "negative_fill": PatternFill("solid", fgColor="FFC7CE"),
        "neutral_fill": PatternFill("solid", fgColor="FFEB9C"),
        "light_fill": PatternFill("solid", fgColor="EBF3FB"),
        "title_font": Font(bold=True, name="Arial", size=14, color="1F3864"),
        "border": Border(
            left=Side(style="thin"), right=Side(style="thin"),
            top=Side(style="thin"), bottom=Side(style="thin")
        ),
        "bold_font": Font(bold=True, name="Arial", size=10),
        "normal_font": Font(name="Arial", size=10),
    }


def _apply_border(ws, row, col_start, col_end, s):
    for c in range(col_start, col_end + 1):
        ws.cell(row=row, column=c).border = s["border"]


def _header_row(ws, row, cols, labels, s, fill_key="header_fill"):
    fill = s[fill_key]
    font = s["header_font"] if fill_key == "header_fill" else s["section_font"]
    for i, label in enumerate(labels):
        cell = ws.cell(row=row, column=cols[i])
        cell.value = label
        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = s["border"]


# ─────────────────────────────────────────────────
# CÁLCULOS FINANCIEROS
# ─────────────────────────────────────────────────
def calcular_pl(config, escenario):
    meses = config["horizonte_meses"]
    crec = config["crecimiento_mensual"][escenario]
    pct_desc = config["pct_descuentos"][escenario]
    pct_cogs = config["pct_cogs"][escenario]
    opex_mult = config["opex_multiplicador"][escenario]

    lineas = config["lineas_ingreso"]
    opex_base = config["opex_fijo"]
    cogs_desg = config["cogs_desglose"]
    tasa_ir = config["tasa_ir"]

    pl = []
    for m in range(1, meses + 1):
        factor = (1 + crec) ** (m - 1)

        # Ingresos
        ventas_brutas = sum(
            l["precio"] * l["unidades_m1"] * factor for l in lineas
        )
        descuentos = ventas_brutas * pct_desc
        ventas_netas = ventas_brutas - descuentos

        # COGS
        cogs_total = ventas_netas * pct_cogs
        cogs_lineas = {k: cogs_total * v for k, v in cogs_desg.items()}
        utilidad_bruta = ventas_netas - cogs_total
        margen_bruto = utilidad_bruta / ventas_netas if ventas_netas else 0

        # OPEX
        opex_lineas = {k: v * opex_mult for k, v in opex_base.items()}
        opex_total = sum(opex_lineas.values())
        depreciacion = opex_lineas.get("Depreciación Equipos", 0)

        utilidad_operativa = utilidad_bruta - opex_total
        ebitda = utilidad_operativa + depreciacion
        margen_ebitda = ebitda / ventas_netas if ventas_netas else 0

        # Otros / IR
        ingresos_financieros = 0
        gastos_financieros = 0
        uai = utilidad_operativa + ingresos_financieros - gastos_financieros
        ir = max(0, uai * tasa_ir)
        utilidad_neta = uai - ir
        margen_neto = utilidad_neta / ventas_netas if ventas_netas else 0

        pl.append({
            "mes": m,
            "ventas_brutas": ventas_brutas,
            "descuentos": descuentos,
            "ventas_netas": ventas_netas,
            "cogs_lineas": cogs_lineas,
            "cogs_total": cogs_total,
            "utilidad_bruta": utilidad_bruta,
            "margen_bruto": margen_bruto,
            "opex_lineas": opex_lineas,
            "opex_total": opex_total,
            "depreciacion": depreciacion,
            "utilidad_operativa": utilidad_operativa,
            "ebitda": ebitda,
            "margen_ebitda": margen_ebitda,
            "uai": uai,
            "ir": ir,
            "utilidad_neta": utilidad_neta,
            "margen_neto": margen_neto,
        })
    return pl


def calcular_fcl(pl_data, config):
    dias_cobro = config["dias_cobro"]
    dias_inv = config["dias_inventario"]
    dias_pago = config["dias_pago"]

    fcl_list = []
    prev_cxc = 0
    prev_inv = 0
    prev_cxp = 0

    for i, m in enumerate(pl_data):
        # Capital de trabajo
        cxc = m["ventas_netas"] / 30 * dias_cobro
        inv = m["cogs_total"] / 30 * dias_inv
        cxp = m["cogs_total"] / 30 * dias_pago
        delta_ct = (cxc - prev_cxc) + (inv - prev_inv) - (cxp - prev_cxp)

        capex = config["inversion_inicial"] if i == 0 else 0
        fcl = m["utilidad_neta"] + m["depreciacion"] - delta_ct - capex

        prev_cxc, prev_inv, prev_cxp = cxc, inv, cxp
        fcl_list.append(fcl)
    return fcl_list


def calcular_van(fcl_list, tasa_anual):
    r = (1 + tasa_anual) ** (1 / 12) - 1
    return sum(f / (1 + r) ** (t + 1) for t, f in enumerate(fcl_list))


def calcular_tir(fcl_list, inversion):
    flujos = [-inversion] + fcl_list
    # Método bisección
    low, high = -0.999, 10.0
    for _ in range(1000):
        mid = (low + high) / 2
        van = sum(f / (1 + mid) ** t for t, f in enumerate(flujos))
        if abs(van) < 0.01:
            break
        if van > 0:
            low = mid
        else:
            high = mid
    tir_mensual = mid
    tir_anual = (1 + tir_mensual) ** 12 - 1
    return tir_anual


def calcular_payback(fcl_list, inversion):
    acum = -inversion
    for i, f in enumerate(fcl_list):
        acum += f
        if acum >= 0:
            # Interpolación
            prev = acum - f
            fraccion = abs(prev) / f if f else 0
            return i + fraccion
    return None  # No recupera


def calcular_breakeven(config, escenario):
    opex_mult = config["opex_multiplicador"][escenario]
    pct_cogs = config["pct_cogs"][escenario]
    opex_total = sum(config["opex_fijo"].values()) * opex_mult
    margen_contrib_pct = 1 - pct_cogs
    be_ventas = opex_total / margen_contrib_pct if margen_contrib_pct else float("inf")
    return be_ventas


def calcular_sensibilidad(config):
    """Matriz 5x5: VAN según variación de precio y volumen"""
    variaciones = [-0.20, -0.10, 0.0, 0.10, 0.20]
    resultado = []
    for delta_precio in variaciones:
        fila = []
        for delta_vol in variaciones:
            cfg_mod = json.loads(json.dumps(config))
            for l in cfg_mod["lineas_ingreso"]:
                l["precio"] *= (1 + delta_precio)
                l["unidades_m1"] = int(l["unidades_m1"] * (1 + delta_vol))
            pl = calcular_pl(cfg_mod, "moderado")
            fcl = calcular_fcl(pl, cfg_mod)
            van = calcular_van(fcl, cfg_mod["tasa_descuento_anual"])
            fila.append(round(van, 0))
        resultado.append(fila)
    return resultado


# ─────────────────────────────────────────────────
# HOJAS DEL EXCEL
# ─────────────────────────────────────────────────
def write_supuestos(wb, config, s):
    ws = wb.create_sheet("Supuestos")
    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 22
    ws.column_dimensions["C"].width = 35

    # Título
    ws.merge_cells("A1:C1")
    c = ws["A1"]
    c.value = f"📋 SUPUESTOS — {config['empresa'].upper()}"
    c.font = s["title_font"]
    c.alignment = Alignment(horizontal="center")

    row = 3
    def sec(title):
        nonlocal row
        ws.merge_cells(f"A{row}:C{row}")
        c = ws.cell(row=row, column=1)
        c.value = title
        c.fill = s["section_fill"]
        c.font = s["section_font"]
        c.alignment = Alignment(horizontal="left")
        row += 1

    def inp(label, value, nota=""):
        nonlocal row
        ws.cell(row=row, column=1).value = label
        ws.cell(row=row, column=1).font = s["normal_font"]
        v_cell = ws.cell(row=row, column=2)
        v_cell.value = value
        v_cell.font = s["input_font"]
        v_cell.alignment = Alignment(horizontal="right")
        if nota:
            ws.cell(row=row, column=3).value = nota
            ws.cell(row=row, column=3).font = Font(italic=True, color="666666", name="Arial", size=9)
        row += 1

    sec("📌 INFORMACIÓN GENERAL")
    inp("Empresa / Proyecto", config["empresa"])
    inp("Sector / Industria", config["sector"])
    inp("País", config["pais"])
    inp("Moneda", config["moneda"])
    inp("Horizonte de proyección (meses)", config["horizonte_meses"])
    inp("Régimen tributario", config["regimen"])

    row += 1
    sec("💰 INVERSIÓN Y FINANCIAMIENTO")
    inp("Inversión Inicial (CAPEX)", config["inversion_inicial"], "Equipos, capital de trabajo inicial")
    inp("Caja Inicial Disponible", config["caja_inicial"])
    inp("Tasa de Descuento Anual", f"{config['tasa_descuento_anual']*100:.1f}%", "Costo de oportunidad / WACC")
    inp("Tasa Impuesto a la Renta", f"{config['tasa_ir']*100:.1f}%")

    row += 1
    sec("📈 CRECIMIENTO MENSUAL POR ESCENARIO")
    inp("Conservador", f"{config['crecimiento_mensual']['conservador']*100:.0f}%")
    inp("Moderado (Base)", f"{config['crecimiento_mensual']['moderado']*100:.0f}%")
    inp("Optimista", f"{config['crecimiento_mensual']['optimista']*100:.0f}%")

    row += 1
    sec("🛒 LÍNEAS DE INGRESO (Mes 1)")
    for l in config["lineas_ingreso"]:
        inp(l["nombre"], f"Precio: {config['moneda']}{l['precio']:.2f} | Und: {l['unidades_m1']}")

    row += 1
    sec("📦 COGS como % de Ventas Netas")
    inp("Conservador", f"{config['pct_cogs']['conservador']*100:.0f}%")
    inp("Moderado (Base)", f"{config['pct_cogs']['moderado']*100:.0f}%")
    inp("Optimista", f"{config['pct_cogs']['optimista']*100:.0f}%")

    row += 1
    sec("💼 GASTOS OPERATIVOS MENSUALES (BASE)")
    for k, v in config["opex_fijo"].items():
        inp(k, f"{config['moneda']}{v:,.0f}")

    row += 1
    sec("📅 CAPITAL DE TRABAJO")
    inp("Días de cobro (CxC)", config["dias_cobro"])
    inp("Días de inventario", config["dias_inventario"])
    inp("Días de pago a proveedores", config["dias_pago"])

    ws.freeze_panes = "A3"


def write_pl_sheet(wb, config, escenario, pl_data, s):
    nombre = f"P&L_{escenario.capitalize()}"
    ws = wb.create_sheet(nombre)

    meses = config["horizonte_meses"]
    moneda = config["moneda"]
    col_total = meses + 3  # Col A = concepto, B = mes1, ...

    ws.column_dimensions["A"].width = 33
    for c in range(2, meses + 3):
        ws.column_dimensions[get_column_letter(c)].width = 12

    # Título
    ws.merge_cells(f"A1:{get_column_letter(meses + 2)}1")
    t = ws["A1"]
    colores = {"conservador": "4472C4", "moderado": "ED7D31", "optimista": "70AD47"}
    t.value = f"📊 ESTADO DE RESULTADOS — {escenario.upper()} | {config['empresa']}"
    t.font = Font(bold=True, name="Arial", size=12, color=colores.get(escenario, "1F3864"))
    t.alignment = Alignment(horizontal="center")

    # Encabezados de columna
    header_cols = [1] + list(range(2, meses + 3))
    labels = ["Concepto"] + [f"M{m}" for m in range(1, meses + 1)] + ["TOTAL"]
    _header_row(ws, 2, header_cols, labels, s)

    def write_row(row, label, valores, bold=False, pct=False, fill=None):
        c = ws.cell(row=row, column=1)
        c.value = label
        c.font = s["bold_font"] if bold else s["normal_font"]
        if fill:
            c.fill = fill
        total = sum(v for v in valores if v is not None)
        for col, v in enumerate(valores, start=2):
            cell = ws.cell(row=row, column=col)
            if v is None:
                continue
            cell.value = v
            cell.font = s["formula_font"]
            if pct:
                cell.number_format = "0.0%"
            else:
                cell.number_format = f'"{moneda}" #,##0;("{moneda}" #,##0);"-"'
            if fill:
                cell.fill = fill
            _apply_border(ws, row, 1, meses + 2, s)
        # Total
        total_cell = ws.cell(row=row, column=meses + 2)
        total_cell.value = total
        if pct:
            total_cell.value = sum(valores) / len(valores)
            total_cell.number_format = "0.0%"
        else:
            total_cell.number_format = f'"{moneda}" #,##0;("{moneda}" #,##0);"-"'

    def section(row, title):
        ws.merge_cells(f"A{row}:{get_column_letter(meses+2)}{row}")
        c = ws.cell(row=row, column=1)
        c.value = title
        c.fill = s["section_fill"]
        c.font = s["section_font"]

    r = 3
    section(r, "I. INGRESOS"); r += 1
    write_row(r, "Ventas Brutas", [m["ventas_brutas"] for m in pl_data]); r += 1
    write_row(r, "(-) Descuentos y Devoluciones", [-m["descuentos"] for m in pl_data]); r += 1
    write_row(r, "VENTAS NETAS", [m["ventas_netas"] for m in pl_data],
              bold=True, fill=s["light_fill"]); r += 1

    section(r, "II. COSTO DE VENTAS (COGS)"); r += 1
    cogs_keys = list(pl_data[0]["cogs_lineas"].keys())
    for k in cogs_keys:
        write_row(r, f"  {k}", [m["cogs_lineas"][k] for m in pl_data]); r += 1
    write_row(r, "COGS TOTAL", [m["cogs_total"] for m in pl_data],
              bold=True, fill=s["light_fill"]); r += 1
    write_row(r, "UTILIDAD BRUTA", [m["utilidad_bruta"] for m in pl_data],
              bold=True, fill=s["positive_fill"]); r += 1
    write_row(r, "Margen Bruto (%)", [m["margen_bruto"] for m in pl_data], pct=True); r += 1

    section(r, "III. GASTOS OPERATIVOS (OPEX)"); r += 1
    opex_keys = list(pl_data[0]["opex_lineas"].keys())
    for k in opex_keys:
        write_row(r, f"  {k}", [m["opex_lineas"][k] for m in pl_data]); r += 1
    write_row(r, "OPEX TOTAL", [m["opex_total"] for m in pl_data],
              bold=True, fill=s["light_fill"]); r += 1
    write_row(r, "UTILIDAD OPERATIVA", [m["utilidad_operativa"] for m in pl_data],
              bold=True); r += 1
    write_row(r, "EBITDA (aprox.)", [m["ebitda"] for m in pl_data],
              bold=True, fill=s["light_fill"]); r += 1
    write_row(r, "Margen EBITDA (%)", [m["margen_ebitda"] for m in pl_data], pct=True); r += 1

    section(r, "IV. OTROS INGRESOS / GASTOS"); r += 1
    write_row(r, "  Ingresos Financieros", [0] * meses); r += 1
    write_row(r, "  Gastos Financieros", [0] * meses); r += 1
    write_row(r, "UTILIDAD ANTES IMPUESTOS", [m["uai"] for m in pl_data],
              bold=True, fill=s["light_fill"]); r += 1
    write_row(r, "  Impuesto a la Renta", [m["ir"] for m in pl_data]); r += 1
    write_row(r, "UTILIDAD NETA", [m["utilidad_neta"] for m in pl_data],
              bold=True, fill=s["positive_fill"]); r += 1
    write_row(r, "Margen Neto (%)", [m["margen_neto"] for m in pl_data], pct=True); r += 1

    ws.freeze_panes = "B3"


def write_flujo_caja(wb, config, pl_conserv, pl_moder, pl_optim, s):
    ws = wb.create_sheet("Flujo_de_Caja")
    meses = config["horizonte_meses"]
    moneda = config["moneda"]

    ws.column_dimensions["A"].width = 30
    for c in range(2, meses + 4):
        ws.column_dimensions[get_column_letter(c)].width = 12

    ws.merge_cells(f"A1:{get_column_letter(meses+3)}1")
    t = ws["A1"]
    t.value = f"💵 FLUJO DE CAJA LIBRE — {config['empresa']}"
    t.font = s["title_font"]
    t.alignment = Alignment(horizontal="center")

    labels = ["Concepto"] + [f"M{m}" for m in range(1, meses + 1)] + ["TOTAL", ""]
    _header_row(ws, 2, list(range(1, meses + 4)), labels[:-1], s)

    r = 3
    for escenario, pl_data in [("Conservador", pl_conserv),
                                ("Moderado", pl_moder),
                                ("Optimista", pl_optim)]:
        fcl = calcular_fcl(pl_data, config)
        colores_fill = {
            "Conservador": "4472C4", "Moderado": "ED7D31", "Optimista": "70AD47"
        }

        ws.merge_cells(f"A{r}:{get_column_letter(meses+2)}{r}")
        c = ws.cell(row=r, column=1)
        c.value = f"── ESCENARIO {escenario.upper()} ──"
        c.fill = PatternFill("solid", fgColor=colores_fill[escenario])
        c.font = Font(bold=True, color="FFFFFF", name="Arial", size=10)
        r += 1

        rows_data = [
            ("Utilidad Neta", [m["utilidad_neta"] for m in pl_data]),
            ("(+) Depreciación", [m["depreciacion"] for m in pl_data]),
            ("(-) CAPEX", [-config["inversion_inicial"] if i == 0 else 0
                           for i in range(meses)]),
        ]
        acum_fcl = 0
        fcl_acum = []
        for v in fcl:
            acum_fcl += v
            fcl_acum.append(acum_fcl)

        rows_data.append(("FLUJO DE CAJA LIBRE (FCL)", fcl))
        rows_data.append(("FCL Acumulado", fcl_acum))

        for label, valores in rows_data:
            bold = "FLUJO" in label or "Acumulado" in label
            fill = s["positive_fill"] if "FLUJO" in label else None
            ws.cell(row=r, column=1).value = label
            ws.cell(row=r, column=1).font = s["bold_font"] if bold else s["normal_font"]
            if fill:
                ws.cell(row=r, column=1).fill = fill
            total = sum(valores)
            for col, v in enumerate(valores, start=2):
                cell = ws.cell(row=r, column=col)
                cell.value = v
                cell.font = s["formula_font"]
                cell.number_format = f'"{moneda}" #,##0;("{moneda}" #,##0);"-"'
                if fill:
                    cell.fill = fill
                    if v >= 0:
                        cell.fill = s["positive_fill"]
                    else:
                        cell.fill = s["negative_fill"]
            ws.cell(row=r, column=meses + 2).value = total
            ws.cell(row=r, column=meses + 2).number_format = f'"{moneda}" #,##0;("{moneda}" #,##0);"-"'
            r += 1
        r += 1

    ws.freeze_panes = "B3"


def write_indicadores(wb, config, s):
    ws = wb.create_sheet("Indicadores")
    moneda = config["moneda"]

    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 20
    ws.column_dimensions["C"].width = 20
    ws.column_dimensions["D"].width = 20

    ws.merge_cells("A1:D1")
    t = ws["A1"]
    t.value = f"📊 INDICADORES DE VIABILIDAD — {config['empresa']}"
    t.font = s["title_font"]
    t.alignment = Alignment(horizontal="center")

    _header_row(ws, 3, [1, 2, 3, 4],
                ["Indicador", "🔵 Conservador", "🟡 Moderado", "🟢 Optimista"], s)

    indicadores = {}
    for escenario in ["conservador", "moderado", "optimista"]:
        pl = calcular_pl(config, escenario)
        fcl = calcular_fcl(pl, config)
        van = calcular_van(fcl, config["tasa_descuento_anual"])
        try:
            tir = calcular_tir(fcl, config["inversion_inicial"])
        except Exception:
            tir = None
        payback = calcular_payback(fcl, config["inversion_inicial"])
        be_ventas = calcular_breakeven(config, escenario)
        mb = sum(m["margen_bruto"] for m in pl) / len(pl)
        me = sum(m["margen_ebitda"] for m in pl) / len(pl)
        br = sum(-m["utilidad_neta"] for m in pl if m["utilidad_neta"] < 0) / max(
            sum(1 for m in pl if m["utilidad_neta"] < 0), 1
        )
        runway = config["caja_inicial"] / br if br > 0 else None

        indicadores[escenario] = {
            "VAN": van,
            "TIR": tir,
            "Payback (meses)": payback,
            "Break-even (S// mes)": be_ventas,
            "Margen Bruto Prom. (%)": mb,
            "Margen EBITDA Prom. (%)": me,
            "Burn Rate Prom. (S//mes)": br,
            "Runway (meses)": runway,
        }

    row = 4
    for ind_name in indicadores["conservador"].keys():
        ws.cell(row=row, column=1).value = ind_name
        ws.cell(row=row, column=1).font = s["bold_font"]
        for col, esc in enumerate(["conservador", "moderado", "optimista"], start=2):
            val = indicadores[esc][ind_name]
            cell = ws.cell(row=row, column=col)
            if val is None:
                cell.value = "N/D"
            elif "%" in ind_name:
                cell.value = val
                cell.number_format = "0.0%"
            elif "Payback" in ind_name or "Runway" in ind_name:
                cell.value = round(val, 1) if val else "N/D"
                cell.number_format = '0.0" meses"'
            else:
                cell.value = val
                cell.number_format = f'"{moneda}" #,##0;("{moneda}" #,##0);"-"'

            if "VAN" in ind_name:
                if isinstance(val, (int, float)):
                    cell.fill = s["positive_fill"] if val >= 0 else s["negative_fill"]

            cell.font = s["formula_font"]
            cell.alignment = Alignment(horizontal="right")
            cell.border = s["border"]
        ws.cell(row=row, column=1).border = s["border"]
        row += 1

    # Nota metodológica
    row += 2
    ws.cell(row=row, column=1).value = (
        f"Nota: VAN calculado con tasa de descuento {config['tasa_descuento_anual']*100:.0f}% anual "
        f"({((1+config['tasa_descuento_anual'])**(1/12)-1)*100:.2f}% mensual). "
        f"Horizonte: {config['horizonte_meses']} meses."
    )
    ws.cell(row=row, column=1).font = Font(italic=True, name="Arial", size=9, color="666666")
    ws.merge_cells(f"A{row}:D{row}")


def write_sensibilidad(wb, config, s):
    ws = wb.create_sheet("Sensibilidad")
    moneda = config["moneda"]

    ws.merge_cells("A1:G1")
    t = ws["A1"]
    t.value = f"📉 ANÁLISIS DE SENSIBILIDAD — VAN según Precio × Volumen"
    t.font = s["title_font"]
    t.alignment = Alignment(horizontal="center")

    ws.merge_cells("A2:G2")
    ws.cell(row=2, column=1).value = f"Tasa de descuento: {config['tasa_descuento_anual']*100:.0f}% anual | Escenario: Moderado | Moneda: {moneda}"
    ws.cell(row=2, column=1).font = Font(italic=True, name="Arial", size=9)

    labels_vol = ["Precio \\ Volumen", "Vol −20%", "Vol −10%", "Vol BASE", "Vol +10%", "Vol +20%"]
    _header_row(ws, 4, list(range(1, 7)), labels_vol, s)

    labels_precio = ["Precio +20%", "Precio +10%", "Precio BASE", "Precio −10%", "Precio −20%"]
    matriz = calcular_sensibilidad(config)

    for i, (fila, label) in enumerate(zip(matriz, labels_precio)):
        row = 5 + i
        ws.cell(row=row, column=1).value = label
        ws.cell(row=row, column=1).font = s["bold_font"]
        ws.cell(row=row, column=1).fill = s["header_fill"]
        ws.cell(row=row, column=1).font = Font(bold=True, color="FFFFFF", name="Arial", size=10)
        for j, van in enumerate(fila):
            cell = ws.cell(row=row, column=j + 2)
            cell.value = van
            cell.number_format = f'"{moneda}" #,##0;("{moneda}" #,##0);"-"'
            cell.font = Font(bold=True, name="Arial", size=10,
                             color="375623" if van >= 0 else "9C0006")
            cell.fill = s["positive_fill"] if van >= 0 else s["negative_fill"]
            if abs(van) < abs(max(fila, key=abs)) * 0.15:
                cell.fill = s["neutral_fill"]
            cell.alignment = Alignment(horizontal="right")
            cell.border = s["border"]
        ws.cell(row=row, column=1).border = s["border"]

    row = 11
    ws.cell(row=row, column=1).value = "🟢 Verde = VAN > 0 (viable)    🔴 Rojo = VAN < 0 (inviable)    🟡 Amarillo = VAN ≈ 0 (umbral)"
    ws.cell(row=row, column=1).font = Font(italic=True, name="Arial", size=10)
    ws.merge_cells(f"A{row}:G{row}")

    for c in ["A", "B", "C", "D", "E", "F", "G"]:
        ws.column_dimensions[c].width = 16


def write_dashboard(wb, config, s):
    ws = wb.create_sheet("Dashboard")
    moneda = config["moneda"]

    ws.merge_cells("A1:H1")
    t = ws["A1"]
    t.value = f"🚀 DASHBOARD EJECUTIVO — {config['empresa'].upper()}"
    t.font = Font(bold=True, name="Arial", size=16, color="1F3864")
    t.alignment = Alignment(horizontal="center")

    ws.merge_cells("A2:H2")
    ws.cell(row=2, column=1).value = (
        f"Business Case · Generado: {datetime.now().strftime('%d/%m/%Y %H:%M')} · "
        f"Horizonte: {config['horizonte_meses']} meses · Tasa descuento: {config['tasa_descuento_anual']*100:.0f}%"
    )
    ws.cell(row=2, column=1).font = Font(italic=True, name="Arial", size=9, color="666666")

    row = 4
    tarjetas = []
    for escenario in ["conservador", "moderado", "optimista"]:
        pl = calcular_pl(config, escenario)
        fcl = calcular_fcl(pl, config)
        van = calcular_van(fcl, config["tasa_descuento_anual"])
        try:
            tir = calcular_tir(fcl, config["inversion_inicial"])
        except Exception:
            tir = 0
        payback = calcular_payback(fcl, config["inversion_inicial"])
        tarjetas.append((escenario, van, tir, payback))

    col_start = 1
    for esc, van, tir, payback in tarjetas:
        colores = {"conservador": "4472C4", "moderado": "ED7D31", "optimista": "70AD47"}
        emoji = {"conservador": "🔵", "moderado": "🟡", "optimista": "🟢"}

        ws.merge_cells(f"{get_column_letter(col_start)}{row}:{get_column_letter(col_start+1)}{row}")
        c = ws.cell(row=row, column=col_start)
        c.value = f"{emoji[esc]} ESCENARIO {esc.upper()}"
        c.fill = PatternFill("solid", fgColor=colores[esc])
        c.font = Font(bold=True, color="FFFFFF", name="Arial", size=11)
        c.alignment = Alignment(horizontal="center")

        data = [
            ("VAN", f"{moneda}{van:,.0f}", van >= 0),
            ("TIR Anual", f"{tir*100:.1f}%" if tir else "N/D", tir and tir > config["tasa_descuento_anual"]),
            ("Payback", f"{payback:.1f} meses" if payback else "No recupera", payback and payback <= 24),
        ]
        for i, (label, val, ok) in enumerate(data):
            r = row + 1 + i
            ws.cell(row=r, column=col_start).value = label
            ws.cell(row=r, column=col_start).font = s["bold_font"]
            v_cell = ws.cell(row=r, column=col_start + 1)
            v_cell.value = val
            v_cell.font = Font(bold=True, name="Arial", size=11,
                               color="375623" if ok else "9C0006")
            v_cell.alignment = Alignment(horizontal="right")
            for cc in [col_start, col_start + 1]:
                ws.cell(row=r, column=cc).border = s["border"]

        col_start += 3

    for c in ["A", "B", "C", "D", "E", "F", "G", "H"]:
        ws.column_dimensions[c].width = 18

    # Recomendación
    pl_mod = calcular_pl(config, "moderado")
    fcl_mod = calcular_fcl(pl_mod, config)
    van_mod = calcular_van(fcl_mod, config["tasa_descuento_anual"])

    row += 6
    ws.merge_cells(f"A{row}:H{row}")
    rec_text = (
        f"✅ RECOMENDACIÓN: GO — El proyecto genera valor bajo el escenario moderado (VAN {moneda}{van_mod:,.0f})"
        if van_mod >= 0 else
        f"⚠️ RECOMENDACIÓN: AJUSTE ESTRATÉGICO — Revisa estructura de costos (VAN negativo: {moneda}{van_mod:,.0f})"
    )
    c = ws.cell(row=row, column=1)
    c.value = rec_text
    c.font = Font(bold=True, name="Arial", size=12,
                  color="375623" if van_mod >= 0 else "9C0006")
    c.fill = PatternFill("solid", fgColor="C6EFCE" if van_mod >= 0 else "FFC7CE")
    c.alignment = Alignment(horizontal="center")


# ─────────────────────────────────────────────────
# FUNCIÓN PRINCIPAL
# ─────────────────────────────────────────────────
def generate_business_case(config=None):
    if config is None:
        config = DEFAULT_CONFIG

    s = _style()
    wb = Workbook()
    wb.remove(wb.active)  # Eliminar hoja default

    # Calcular P&L para los 3 escenarios
    pl_c = calcular_pl(config, "conservador")
    pl_m = calcular_pl(config, "moderado")
    pl_o = calcular_pl(config, "optimista")

    # Generar hojas
    write_supuestos(wb, config, s)
    write_pl_sheet(wb, config, "conservador", pl_c, s)
    write_pl_sheet(wb, config, "moderado", pl_m, s)
    write_pl_sheet(wb, config, "optimista", pl_o, s)
    write_flujo_caja(wb, config, pl_c, pl_m, pl_o, s)
    write_indicadores(wb, config, s)
    write_sensibilidad(wb, config, s)
    write_dashboard(wb, config, s)

    # Guardar
    empresa_clean = config["empresa"].replace(" ", "_").replace("/", "-")
    fecha = datetime.now().strftime("%Y%m%d")
    filename = f"Business_Case_{empresa_clean}_{fecha}.xlsx"
    filepath = Path("/mnt/user-data/outputs") / filename
    filepath.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(filepath))

    print(f"✅ Business Case generado: {filepath}")
    return str(filepath)


if __name__ == "__main__":
    path = generate_business_case()
    print(f"\n📂 Archivo disponible en: {path}")
    print("💡 Edita la sección DEFAULT_CONFIG para personalizar los supuestos.")
    print("\n   Grupo Biogenia · pl-business-case skill v1.0")
