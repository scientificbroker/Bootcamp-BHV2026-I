# 📊 P&L Business Case Skill
### Asistente Financiero Inteligente para Startups y Empresas Emergentes

---

## ¿Qué es este Skill?

El **pl-business-case skill** es una habilidad de IA diseñada para guiar a emprendedores, fundadores y consultores en la construcción completa de un **Business Case financiero**, desde cero hasta un entregable profesional listo para presentar a inversores, aceleradoras o equipos directivos.

El skill combina:
- 🧭 **Diagnóstico adaptativo** — ajusta el nivel de profundidad al conocimiento del usuario
- 📋 **Recopilación guiada** — preguntas estratégicas organizadas en 6 bloques temáticos
- 📊 **Modelo financiero completo** — P&L, flujo de caja, VAN, TIR, Payback, Break-even
- 🎯 **Tres escenarios** — Conservador, Moderado y Optimista
- 🔬 **Análisis de sensibilidad** — tabla bidimensional Precio × Volumen
- 📁 **Entregable Excel** — archivo `.xlsx` profesional con 8 hojas y formato financiero estándar
- 🤖 **Multi-modelo** — instrucciones específicas para Claude, ChatGPT, Gemini, Mistral y LLaMA 3

---

## Estructura del Skill

```
pl-business-case-skill/
├── SKILL.md                          # Instrucciones principales del skill
├── README.md                         # Este archivo
├── references/
│   ├── pl-estructura.md              # Estructura línea a línea del P&L
│   ├── indicadores-financieros.md    # Fórmulas VAN, TIR, Payback, Break-even
│   ├── business-case-template.md     # Plantilla completa del Business Case
│   ├── nivel-usuario.md              # Adaptación por nivel (Básico/Intermedio/Avanzado)
│   └── guia-modelos-ia.md            # Prompts específicos por modelo de IA
└── scripts/
    └── generate_pl.py                # Script Python para generar el Excel
```

---

## Cómo Usar este Skill

### Opción 1 — Con Claude (Anthropic)

Instala el skill en tu proyecto de Claude y simplemente di:

```
Quiero construir el business case de mi startup.
```

Claude detectará el skill automáticamente y comenzará el flujo de diagnóstico.

**O usa el prompt directo:**
```xml
<role>Usa el skill pl-business-case para guiarme en la construcción del business case 
financiero de mi [startup/negocio/proyecto]. Empieza por preguntarme mi nivel de 
conocimiento financiero.</role>
```

### Opción 2 — Con ChatGPT / GPT-4o

1. Ve a **System Instructions** (ChatGPT personalizado o API)
2. Pega el contenido de `references/guia-modelos-ia.md` → sección ChatGPT
3. Inicia la conversación con: *"Quiero construir el business case de mi startup."*

### Opción 3 — Con Gemini 1.5

1. En Google AI Studio, pega las **System Instructions** de la sección Gemini
2. Activa **Google Grounding** para verificar benchmarks del sector
3. Sube el Excel de referencia si tienes datos previos

### Opción 4 — Generar el Excel directamente

```bash
# Clonar o descargar el skill
cd pl-business-case-skill

# Instalar dependencias
pip install openpyxl --break-system-packages

# Editar los supuestos en generate_pl.py → sección DEFAULT_CONFIG
nano scripts/generate_pl.py

# Ejecutar
python3 scripts/generate_pl.py
```

El archivo se guarda automáticamente como `Business_Case_[Empresa]_[Fecha].xlsx`.

---

## Flujo de Conversación

```
Usuario inicia
      │
      ▼
[Fase 0] Diagnóstico de nivel
  ├── 🌱 Básico      → Lenguaje simple, ejemplos cotidianos
  ├── 🌿 Intermedio  → Términos financieros con definición breve
  └── 🌳 Avanzado    → Terminología profesional completa
      │
      ▼
[Fase 1] Recopilación por bloques (máx. 3 preguntas por turno)
  ├── Bloque A: Identidad del negocio
  ├── Bloque B: Ingresos
  ├── Bloque C: COGS
  ├── Bloque D: Gastos operativos
  ├── Bloque E: Inversión y financiamiento
  └── Bloque F: Impuestos y régimen
      │
      ▼
[Fase 2] Generación de 3 escenarios
  ├── 🔵 Conservador
  ├── 🟡 Moderado (base)
  └── 🟢 Optimista
      │
      ▼
[Fase 3] Análisis de sensibilidad
  └── Tabla 5×5: VAN según Precio × Volumen
      │
      ▼
[Fase 4] Business Case completo
  └── 9 secciones: Resumen Ejecutivo → Conclusión Go/No-Go
      │
      ▼
[Fase 5] Entregable Excel (.xlsx)
  └── 8 hojas: Supuestos · P&L x3 · FCL · Indicadores · Sensibilidad · Dashboard
```

---

## Indicadores que Calcula

| Indicador | Descripción | Fórmula base |
|-----------|-------------|--------------|
| **VAN** | Valor Actual Neto | `Σ FCLₜ/(1+r)ᵗ − Inversión` |
| **TIR** | Tasa Interna de Retorno | Tasa que hace VAN = 0 |
| **Payback** | Período de recuperación | Meses para FCL acumulado ≥ 0 |
| **Break-even** | Punto de equilibrio | `Costos Fijos / Margen de Contribución` |
| **Margen Bruto** | Rentabilidad sobre ventas | `(Ventas − COGS) / Ventas` |
| **EBITDA** | Utilidad antes de intereses/impuestos | `Utilidad Operativa + Depreciación` |
| **Burn Rate** | Consumo mensual de caja | `Egresos − Ingresos` (si negativo) |
| **Runway** | Meses de caja disponible | `Caja / Burn Rate` |

---

## Escenarios y Variables

| Variable | 🔵 Conservador | 🟡 Moderado | 🟢 Optimista |
|----------|---------------|-------------|--------------|
| Crecimiento ventas | Base −30% | Base | Base +40% |
| Precio | Base −10% | Base | Base +10% |
| COGS % ventas | Base +8% | Base | Base −5% |
| OPEX | Base +10% | Base | Base −5% |
| Tasa de descuento | Base +3% | Base | Base −2% |

---

## El Excel Generado — Hojas

| Hoja | Contenido |
|------|-----------|
| `Supuestos` | Todos los inputs en **azul** (editables) |
| `P&L_Conservador` | Estado de Resultados 12 meses — escenario pesimista |
| `P&L_Moderado` | Estado de Resultados 12 meses — escenario base |
| `P&L_Optimista` | Estado de Resultados 12 meses — escenario optimista |
| `Flujo_de_Caja` | FCL mensual para los 3 escenarios con acumulado |
| `Indicadores` | VAN, TIR, Payback, Break-even comparados |
| `Sensibilidad` | Matriz 5×5 Precio × Volumen con colores semáforo |
| `Dashboard` | Resumen ejecutivo visual con recomendación automática |

---

## Compatibilidad con Modelos de IA

| Modelo | Versión recomendada | Funcionalidad completa |
|--------|--------------------|-----------------------|
| **Claude** | claude-sonnet-4 / opus-4 | ✅ Completa + generación de Excel |
| **ChatGPT** | GPT-4o con Code Interpreter | ✅ Completa + visualizaciones |
| **Gemini** | 1.5 Pro / Flash | ✅ Completa + Google Grounding |
| **Mistral** | Large Latest | ✅ Completa + JSON Mode |
| **LLaMA 3** | 70B Instruct | ⚡ Completa (local/privado) |

Ver instrucciones detalladas de prompting en `references/guia-modelos-ia.md`.

---

## Requisitos Técnicos

### Para ejecutar el script Python
```
Python >= 3.8
openpyxl >= 3.1.0
```

Instalación:
```bash
pip install openpyxl
```

### Para usar con Claude (claude.ai)
- Cuenta Claude Pro o Team
- Proyecto con el skill instalado
- No requiere instalación adicional

---

## Personalización del Modelo

Para adaptar el skill a tu industria o caso de uso específico:

1. **Editar `references/pl-estructura.md`** — Agrega líneas de ingreso o costos específicos de tu sector
2. **Editar `DEFAULT_CONFIG` en `generate_pl.py`** — Personaliza los supuestos por defecto
3. **Editar `references/nivel-usuario.md`** — Ajusta el vocabulario para tu audiencia objetivo
4. **Editar `references/business-case-template.md`** — Modifica las secciones del Business Case

---

## Ejemplo de Output del Business Case

```
══════════════════════════════════════════════════════
            BUSINESS CASE — ANÁLISIS DE VIABILIDAD
══════════════════════════════════════════════════════
Empresa:     EcoFoodStartup SAC
Sector:      FoodTech / Alimentos Saludables
País:        Perú
Fecha:       Abril 2026

📊 INDICADORES CLAVE (Escenario Moderado)
┌─────────────────────┬──────────────┐
│ VAN                 │ S/ 12,450    │
│ TIR Anual           │ 34.2%        │
│ Payback             │ 18.3 meses   │
│ Break-even          │ S/ 7,200/mes │
│ Margen Bruto (prom) │ 48.5%        │
└─────────────────────┴──────────────┘

✅ RECOMENDACIÓN: GO
El proyecto genera valor positivo bajo el escenario base.
La TIR (34.2%) supera la tasa de descuento (20%).
══════════════════════════════════════════════════════
```

---

## Licencia y Uso

Este skill es de uso libre para fines educativos, profesionales y comerciales.
Se solicita mantener la atribución al **Grupo Biogenia** en cualquier derivado o adaptación.

---

## Contribuciones y Soporte

Para reportar errores, proponer mejoras o adaptar el skill a un caso de uso específico,
contacta al equipo de desarrollo a través de los canales del **Grupo Biogenia**.

---

<br>

---

<div align="center">

**Desarrollado con 💙 por**

## 🌿 Grupo Biogenia

*Innovación · Formación · Impacto*

*Especialistas en educación financiera, gestión empresarial y herramientas de IA aplicadas  
para emprendedores y organizaciones de alto impacto en América Latina.*

---

© 2025 Grupo Biogenia. Todos los derechos reservados.  
`pl-business-case skill v1.0` — Compatible con Claude, ChatGPT, Gemini, Mistral y LLaMA 3

</div>
